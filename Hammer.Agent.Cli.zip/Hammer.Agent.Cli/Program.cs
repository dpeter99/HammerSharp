﻿// See https://aka.ms/new-console-template for more information

using System.CommandLine;


class Program
{
    static async Task<int> Main(string[] args)
    {
        var rootCommand = new RootCommand("Hammer Agent ClI");

        rootCommand.SetHandler(() =>
        {
            Console.WriteLine("Hello World");
        });
        try
        {
            return await rootCommand.InvokeAsync(args);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }
}


